﻿<?php
/**
 * AppCMS: (C)2013  
 * AppCMS is a free open source mobile phone APP application download website content management system.
 * Custom development, production BUG report template, please contact loyjers@qq.com
 * Author: crane
 * Editor: crane
 */

/**
 * 定义数据库配置参数
 */
// 数据库host名称
define('DB_HOST', 'localhost');
// 数据库用户名
define('DB_USERNAME', 'root');
//数据库密码
define('DB_PASS', 'root');
//数据库
define('DB_DBNAME', 'appcms');
//数据库编码
define('DB_CHARSET', 'utf8');
//表名前缀
define('TB_PREFIX', 'appcms_');

