<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>AppCMS安装</title>
<script type="text/javascript" src="../templates/lib/jquery-1.7.1.min.js"></script>
<!--[if lte IE 6]>
<script src="../../templates/lib/png.js" type="text/javascript"></script>
<script type="text/javascript">
    DD_belatedPNG.fix('a, a:hover');
</script>
<![endif]-->
<link rel="stylesheet"  href="css/init.css"  type="text/css" />
<link rel="stylesheet"  href="css/install.css"  type="text/css" />
<script type="text/javascript" src="../templates/lib/common.js"></script>
</head>
<body>
<div class="warp">
    <div class="warp-top"> <!-- 顶部  开始-->
		<div class="top-head">
			<div class="marauto">
				<a href="javascript:void(0);" class="l web-logo"></a> 
				<div class="r bar-right" style="color:#fff;">
					如果安装出现问题 , 请 <a href="http://www.appcms.cc" target="_blank" style="height:22px; line-height:22px;"><font color=red><b>点此咨询</b></font></a> &nbsp;&nbsp;<a href="http://www.appcms.cc" target="_blank" style="height:22px; line-height:22px;">掌易科技</a>
				</div>
			</div>
		</div>
    </div><!-- 顶部 结束-->